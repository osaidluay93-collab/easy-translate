Easy Translate - نسخة PWA

هذه الملفات المحدّثة تضيف manifest وأيقونات وService Worker حتى يتعرّف PWABuilder على التطبيق بوصفه PWA.

طريقة التحديث على GitHub:
1) افتح مستودع easy-translate ثم Code.
2) اختر Add file ثم Upload files.
3) ارفع كل الملفات والمجلدات من هذا المجلد مع الحفاظ على مجلد icons.
4) وافق على استبدال index.html وmanifest.json إذا طُلب ذلك، وأضف service-worker.js ومجلد icons.
5) اضغط Commit changes وانتظر تحديث GitHub Pages.
6) افتح https://www.pwabuilder.com/ وضع رابط موقعك.

ملاحظة: الترجمة تحتاج إنترنت. ملفات PWA لا تعني أن التطبيق أصبح منشوراً في Microsoft Store تلقائياً؛ ما زال يلزم فحصه وتغليفه واستكمال متطلبات المتجر.
